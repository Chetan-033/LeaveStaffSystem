<div class="footer-wrap pd-20 mb-20 card-box">
Continuous Internal Evaluation Tracking System developed by: Chetan and Kanchan  </a>
			</div>